-- =========================================================================
-- fichier 	            : ddl_vide_contenu_base_portPlaisance.sql
-- base 	            : Port de Plaisance
-- auteur(s)        	    : E.ABBASI
-- date 	            : 30/01/2020
-- role 	            : ddl_vide_contenu_base_portPlaisance
-- projet 	            : Port de Plaisance
-- resultat dans            : ddl_vide_contenu_base_portPlaisance.out
-- ==========================================================================
DELETE FROM EMPLACEMENT;
DELETE FROM PROPRIETAIRE;
DELETE FROM TYPE_EMPLACEMENT;