-- ============================================================================
-- Fichier          : testRelationContrat_DINV_fk.sql 
-- Auteur           : E.ABBASI				
-- Date             : 03/02/2020 						
-- Role             : tester les contraintes d'inegrite statiques definies sur la 
-- 	                  relation Contrat dans le domaine INVALIDE
-- Fichier resultat : testRelationContrat_DINV_fk.out 
-- ============================================================================
ALTER SESSION SET NLS_DATE_FORMAT='dd/mm/yyyy';

-- ============================================================================
-- NB : le test est effectu� sur une base vide, donc on fait la
-- suppression de tous les nuplets de toutes les relations.
-- Prise en charge des dependances de reference dans l'ordre de suppression
-- du contenu des relations de la base de donnees. 
-- ============================================================================
@ videContenuBase.sql
-- ============================================================================
-- Insertion dans les relations referencees par RelationContrat
-- ============================================================================
-- A COMPLETER
INSERT INTO PROPRIETAIRE(ID_PROP,NOMPROP,ADRESSE,VILLE,CODPOSTAL,TEL_PORTABLE)
VALUES (11, 'Damien', '28 rue des sous-bois', 'la Rochelle', 17000, NULL);

INSERT INTO TYPE_EMPLACEMENT(TYP_EMPL,LONGR,LARG,PROFOND)
VALUES(11, 11.11, 11.11, 11.11);

INSERT INTO EMPLACEMENT(ID_EMPL,BASSIN,PONTON,EMPLNO,TYP_EMPL)
VALUES(11, 'vieux-port11', 'K', 11, 11);

-- ============================================================================
-- Jeu de test pour le DOMAINE INVALIDE 
-- ============================================================================
-- Debut de l'ecriture du fichier resultat du programme de test 
spool testRelationContrat_DINV_fk.out  
prompt fichier resultat du test : testRelationContrat_DINV_fk.out

set echo on 
-- ============================================================================
-- Contenu de la table RelationContrat avant INSERT 
-- ============================================================================
set echo off
@presentation
-- On affiche le contenu de la relation RelationContrat
SELECT  *
FROM CONTRAT;

set echo on 
-- ============================================================================
-- Cas : 1 
-- A COMPLETER
INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, CONTRACTANT, EMPLACEMENT)
VALUES (2, '03/02/2020', '15/02/2020', NULL, 'annuel', 11, 11 );

-- ============================================================================
set echo off

-- A COMPLETER

-- Cas : 1 
-- les 2 clés uniques ne réfèrent pas aux tables associé 
-- A COMPLETER
INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, CONTRACTANT, EMPLACEMENT)
VALUES (3, '03/02/2020', '15/02/2020', NULL, 'annuel', 9, 9 );

-- Cas : 2
-- une seule clé uniquese ne réfère pas à la table associé l'autre réfère 
INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, CONTRACTANT, EMPLACEMENT)
VALUES (4, '03/02/2020', '17/02/2020', NULL, 'annuel', 11, 9 );
set echo on 
-- ============================================================================
-- Contenu de la table RelationContrat apr�s INSERT 
-- ============================================================================
set echo off
@presentation
-- On affiche le contenu de la relation RelationContrat
SELECT  *
FROM CONTRAT;

spool off

-- ============================================================================
