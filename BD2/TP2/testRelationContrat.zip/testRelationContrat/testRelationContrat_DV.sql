-- ===========================================================================
-- fichier 	            : testRelationContrat_DV.sql
-- base 	            : Port de Plaisance
-- auteur(s)        	: E.ABBASI
-- date 	            : 03/02/2020
-- role 	            : test de domaine valide
-- projet 	            : Port de Plaisance
-- resultat dans        : testRelationContrat_DV.out
-- ============================================================================
ALTER SESSION SET NLS_DATE_FORMAT='dd/mm/yyyy';
-- ============================================================================
-- NB : le test est effectu� sur une base vide, donc on fait la
-- suppression de tous les nuplets de toutes les relations.
-- Prise en charge des dependances de reference dans l'ordre de suppression
-- du contenu des relations de la base de donnees. 
-- ============================================================================
@vide_contenu_base.sql ;

-- ============================================================================
-- Insertion dans les relations referencees par "xxxxxx" 
-- ============================================================================
-- A COMPLETER

INSERT INTO PROPRIETAIRE(ID_PROP,NOMPROP,ADRESSE,VILLE,CODPOSTAL,TEL_PORTABLE)
VALUES (1, 'Damien', '28 rue des sous-bois', 'la Rochelle', 17000, NULL);

INSERT INTO TYPE_EMPLACEMENT(TYP_EMPL,LONGR,LARG,PROFOND)
VALUES(2, 11.11, 11.11, 11.11);

INSERT INTO EMPLACEMENT(ID_EMPL,BASSIN,PONTON,EMPLNO,TYP_EMPL)
VALUES(1, 'vieux-port1', 'A', 1, 2);

-- ============================================================================
-- Jeu de test pour le DOMAINE VALIDE 
-- ============================================================================
-- ============================================================================
-- Cas 1
-- insertion d'un nuplet verifiant 
------- toutes les contraintes de check
------- toutes les d�pendances de r�f�rence sur attributs non NULL 
------- avec les valeurs nulles possibles
-- ============================================================================
-- A COMPLETER

INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, 
                     CONTRACTANT, EMPLACEMENT)
VALUES (1, '03/02/2020', '06/02/2020', NULL, 'annuel', 1, 1 );


-- ============================================================================
-- Cas 2
-- insertion d'un nuplet verifiant : 
------- toutes les contraintes de cl�s
------- toutes les contraintes de check (attributs non null)
------- toutes les d�pendances de reference (attributs non null)
------- avec les valeurs nulles possibles
-- ============================================================================
-- A COMPLETER
INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, 
                     CONTRACTANT, EMPLACEMENT)
VALUES (2, '03/03/2020', '05/03/2020', NULL, 'annuel', 1, 1 );


-- ============================================================================
-- Cas 3
-- insertion d'un nuplet verifiant : 
------- toutes les contraintes de cles
------- toutes les contraintes de check (attributs non null) 
------- toutes les dependances de reference (attributs non null)
------- avec les valeurs par defaut 
------- et sans les valeurs nulles
-- ============================================================================
-- A COMPLETER
INSERT INTO CONTRAT (NUMCONTRAT, DATESIGNATURE, DEBCONTRAT, FINCONTRAT, TYPECONTRAT, 
                     CONTRACTANT, EMPLACEMENT)
VALUES (3, '03/01/2020', '07/01/2020', '09/02/2020', 'annuel', 1, 1 );


-- ============================================================================
-- Affichage du contenu des differentes relations et verification de la bonne 
-- affectation des valeurs initiales 
-- Resultats a mettre dans le fichier a nommer obligatoirement: 
-- testRelationxxxxxx.out
-- ============================================================================

-- Debut de l'ecriture du fichier resultat du programme de test 
spool testRelationContrat_DV.out  
prompt fichier resultat du test : testRelationContrat_DV.out

-- appel du fichier de presentation
@presentation.sql

-- Afficher le contenu des relations de la base de donnees
prompt Contenu de la base : 
set echo on
@afficher_contenu_base.sql
set echo off

spool off

-- ============================================================================
-- fin du programme de test
-- ============================================================================
