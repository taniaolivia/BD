-- =========================================================================
-- fichier 	            : ddl_presentation_portPlaisance.sql
-- base 	            : Port de Plaisance
-- auteur(s)        	    : E.ABBASI
-- date 	            : 30/01/2020
-- role 	            : presentation_portPlaisance
-- projet 	            : Port de Plaisance
-- resultat dans            : ddl_presentation_portPlaisance.out
-- ==========================================================================

CLEAR COLUMNS;
COLUMN NOMBAT FORMAT a10;
COLUMN NOMPROP FORMAT a10;
COLUMN ADRESSE FORMAT a20;
COLUMN BASSIN FORMAT a11;
COLUMN CONSTRUCT FORMAT a10;
COLUMN VILLE FORMAT a15;
COLUMN TYPECONTRAT FORMAT a15;
