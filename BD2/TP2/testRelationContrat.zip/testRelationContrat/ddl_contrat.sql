-- =========================================================================
-- fichier 	            : ddl_contrat.sql
-- base 	            : Port de Plaisance
-- auteur(s)        	: E.ABBASI
-- date 	            : 03/02/2020
-- role 	            : création de la relations contrat 
-- projet 	            : Port de Plaisance
-- resultat dans        : ddl_contrat.out
-- ==========================================================================

-- TABLE CONTRAT
CREATE TABLE CONTRAT(
    NUMCONTRAT         NUMBER                        NOT NULL,
    DATESIGNATURE      DATE                          NOT NULL,
    DEBCONTRAT         DATE                          NOT NULL,
    FINCONTRAT         DATE                              NULL,
    TYPECONTRAT        VARCHAR2(20) DEFAULT 'annuel' NOT NULL,
    CONTRACTANT        NUMBER                        NOT NULL,
    EMPLACEMENT        NUMBER                        NOT NULL,
    CONSTRAINT PK_CONTRAT PRIMARY KEY (NUMCONTRAT),
    CONSTRAINT UQ_CONTRAT UNIQUE (DEBCONTRAT, EMPLACEMENT),
    CONSTRAINT CK_TYPECONTRAT CHECK (TYPECONTRAT IN('annuel', 'saisonnier',
    'darse_ostriecole','darse_secondaire','hors_darse','ponton_communal')),
    CONSTRAINT CK_DEBCO_DATSI CHECK (DEBCONTRAT >= DATESIGNATURE),
    CONSTRAINT CK_FINCONTRAT  CHECK (FINCONTRAT IS NOT NULL OR 
                                     FINCONTRAT >= DEBCONTRAT) 
    );
    ALTER TABLE CONTRAT ADD 
        CONSTRAINT FK_CONT_PROP FOREIGN KEY (CONTRACTANT) 
        REFERENCES PROPRIETAIRE (ID_PROP);
    ALTER TABLE CONTRAT ADD 
        CONSTRAINT FK_CONT_EMPL FOREIGN KEY (EMPLACEMENT) 
        REFERENCES EMPLACEMENT (ID_EMPL);
    --ALTER TABLE EMPLACEMENT ADD
       -- CONSTRAINT FK_EMPL_TYPEMPL FOREIGN KEY(TYP_EMPL) 
      --  REFERENCES TYPE_EMPLACEMENT (TYP_EMPL);
