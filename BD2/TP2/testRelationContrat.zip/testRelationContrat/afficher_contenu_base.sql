-- =========================================================================
-- fichier 	            : ddl_affiche_contenu_base_portPlaisance.sql
-- base 	            : Port de Plaisance
-- auteur(s)        	    : E.ABBASI
-- date 	            : 30/01/2020
-- role 	            : ddl_affiche_contenu_base_portPlaisance.
-- projet 	            : Port de Plaisance
-- resultat dans            : ddl_affiche_contenu_base_portPlaisance.out
-- ==========================================================================


PROMPT table EMPLACEMENT:
SELECT * FROM EMPLACEMENT;

PROMPT table PROPRIETAIRE:
SELECT * FROM PROPRIETAIRE;

PROMPT table TYPE_EMPLACEMENT:
SELECT * FROM TYPE_EMPLACEMENT;
 