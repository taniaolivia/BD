--==========================
--fichier :presentation_suregeles.sql
--base:
--auteur(s): Tania OLIVIA
--date : 06/11/2019
--role:
--projet: surgelés
--resultat dans:  // à renseigner si nécessaire
--==========================
set linesize 150

COLUMN NOMCLI FORMAT A10
COLUMN PRENOMCLI FORMAT A10
COLUMN TELCLI FORMAT A15
COLUMN MAILCLI FORMAT A18
COLUMN ADRCLI FORMAT A12


