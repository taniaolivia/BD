-- ==========================
-- fichier 	: drop_ruche.sql
-- base 	: ruche
-- auteur(s): Tania OLIVIA
-- date 	: 10/12/2019
-- role 	: supprimer l'ensemble des tables
-- projet 	: ruche
-- resultat dans :
-- ==========================

DROP TABLE RECOLTE CASCADE CONSTRAINTS;
DROP TABLE RUCHE CASCADE CONSTRAINTS;
DROP TABLE APICULTEUR CASCADE CONSTRAINTS;
DROP TABLE RUCHER CASCADE CONSTRAINTS;
