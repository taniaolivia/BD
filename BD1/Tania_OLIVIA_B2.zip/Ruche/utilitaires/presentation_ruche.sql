--==========================
--fichier :presentation_ruche.sql
--base: ruche
--auteur(s): Tania OLIVIA
--date : 10/12/2019
--role:
--projet: ruche
--resultat dans:  // à renseigner si nécessaire
--==========================
set linesize 130

COLUMN NOMAPI FORMAT A10
COLUMN PRENOMAPI FORMAT A10
COLUMN TELAPI FORMAT A15
COLUMN MAILAPI FORMAT A20
COLUMN ADRAPI FORMAT A12




